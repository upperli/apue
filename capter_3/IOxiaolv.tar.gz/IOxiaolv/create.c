#include "apue.h"

int main(int agrc,char * agrv[])
{
	if(agrc < 2)
		return 0;
	int fd;
	if((fd = creat("testfile",FILE_MODE)) < 0)
		err_sys("create error\n");
	int n = atoi(agrv[1]);
	while(n --)
	{
		fputs(fd,"b",1);
	//	if(write(fd,"h",1) < 0)
	//		err_sys("write error\n");
	}
	close(fd);
	return 0;

}